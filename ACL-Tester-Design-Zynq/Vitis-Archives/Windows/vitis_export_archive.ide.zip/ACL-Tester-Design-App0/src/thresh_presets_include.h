/*
 * thresh_presets_include.h
 *
 *  Created on: Jul 18, 2020
 *      Author: timothystotts
 */

#ifndef SRC_THRESH_PRESETS_INCLUDE_H_
#define SRC_THRESH_PRESETS_INCLUDE_H_

extern const uint16_t c_thresh_presets_active_a[2][16];
extern const uint16_t c_thresh_presets_inactive_a[2][16];

#endif /* SRC_THRESH_PRESETS_INCLUDE_H_ */
